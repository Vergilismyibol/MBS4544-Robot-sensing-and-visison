#include <Bluepad32.h>
#include <uni.h>

#define FORWARD 1
#define BACKWARD 2
#define LEFT 3
#define RIGHT 4
#define FORWARD_LEFT 5
#define FORWARD_RIGHT 6
#define BACKWARD_LEFT 7
#define BACKWARD_RIGHT 8
#define ROTATE_LEFT 9
#define ROTATE_RIGHT 10
#define STOP 0

#define BACK_RIGHT_MOTOR 1
#define BACK_LEFT_MOTOR 2
#define FRONT_RIGHT_MOTOR 3
#define FRONT_LEFT_MOTOR 4

#define MAX_MOTOR_SPEED 60 // about 50% duty cycle

unsigned long lastTimeStamp = 0;

//FRONT RIGHT MOTOR
int enableFrontRightMotor = 14; 
int FrontRightMotorPin1 = 26;
int FrontRightMotorPin2 = 27;
//BACK RIGHT MOTOR
int enableBackRightMotor=22; 
int BackRightMotorPin1=16;
int BackRightMotorPin2=17;
//FRONT LEFT MOTOR
int enableFrontLeftMotor = 32;
int FrontLeftMotorPin1 = 33;
int FrontLeftMotorPin2 = 25;
//BACK LEFT MOTOR
int enableBackLeftMotor = 23;
int BackLeftMotorPin1 = 18;
int BackLeftMotorPin2 = 19;

const int PWMFreq = 1000; /* 1 KHz */
const int PWMResolution = 8; // 8-bit
const int PWMSpeedChannel_1 = 1; // 0-15
const int PWMSpeedChannel_2 = 2; // 0-15
const int PWMSpeedChannel_3 = 3; // 0-15
const int PWMSpeedChannel_4 = 4; // 0-15

ControllerPtr myControllers[BP32_MAX_GAMEPADS];
static const char * controller_addr_string = "A0:5A:5E:39:6B:43";

int32_t l_x = 0; 
int32_t l_y = 0;
int32_t r_x = 0;
int32_t r_y = 0;

// This callback gets called any time a new gamepad is connected.
// Up to 4 gamepads can be connected at the same time.
void onConnectedController(ControllerPtr ctl) {
    bool foundEmptySlot = false;
    for (int i = 0; i < BP32_MAX_GAMEPADS; i++) {
        if (myControllers[i] == nullptr) {
            Serial.printf("CALLBACK: Controller is connected, index=%d\n", i);
            // Additionally, you can get certain gamepad properties like:
            // Model, VID, PID, BTAddr, flags, etc.
            ControllerProperties properties = ctl->getProperties();
            Serial.printf("Controller model: %s, VID=0x%04x, PID=0x%04x\n", ctl->getModelName().c_str(), properties.vendor_id,
                           properties.product_id);
            myControllers[i] = ctl;
            foundEmptySlot = true;
            break;
        }
    }
    if (!foundEmptySlot) {
        Serial.println("CALLBACK: Controller connected, but could not found empty slot");
    }
    Serial.println("Connected!");    
}

void onDisconnectedController(ControllerPtr ctl) {
    bool foundController = false;

    for (int i = 0; i < BP32_MAX_GAMEPADS; i++) {
        if (myControllers[i] == ctl) {
            Serial.printf("CALLBACK: Controller disconnected from index=%d\n", i);
            myControllers[i] = nullptr;
            foundController = true;
            break;
        }
        rotateMotor(BACK_RIGHT_MOTOR, 0);
        rotateMotor(BACK_LEFT_MOTOR, 0);
        rotateMotor(FRONT_RIGHT_MOTOR, 0);
        rotateMotor(FRONT_LEFT_MOTOR, 0);        
    }

    if (!foundController) {
        Serial.println("CALLBACK: Controller disconnected, but not found in myControllers");
    }
}

void dumpGamepad(ControllerPtr ctl) {
    Serial.printf(
        "idx=%d, dpad: 0x%02x, buttons: 0x%04x, axis L: %4d, %4d, axis R: %4d, %4d, brake: %4d, throttle: %4d, "
        "misc: 0x%02x, gyro x:%6d y:%6d z:%6d, accel x:%6d y:%6d z:%6d\n",
        ctl->index(),        // Controller Index
        ctl->dpad(),         // D-pad
        ctl->buttons(),      // bitmask of pressed buttons
        ctl->axisX(),        // (-511 - 512) left X Axis
        ctl->axisY(),        // (-511 - 512) left Y axis
        ctl->axisRX(),       // (-511 - 512) right X axis
        ctl->axisRY(),       // (-511 - 512) right Y axis
        ctl->brake(),        // (0 - 1023): brake button
        ctl->throttle(),     // (0 - 1023): throttle (AKA gas) button
        ctl->miscButtons(),  // bitmask of pressed "misc" buttons
        ctl->gyroX(),        // Gyro X
        ctl->gyroY(),        // Gyro Y
        ctl->gyroZ(),        // Gyro Z
        ctl->accelX(),       // Accelerometer X
        ctl->accelY(),       // Accelerometer Y
        ctl->accelZ()        // Accelerometer Z
    );
}

void dumpMouse(ControllerPtr ctl) {
    Serial.printf("idx=%d, buttons: 0x%04x, scrollWheel=0x%04x, delta X: %4d, delta Y: %4d\n",
                   ctl->index(),        // Controller Index
                   ctl->buttons(),      // bitmask of pressed buttons
                   ctl->scrollWheel(),  // Scroll Wheel
                   ctl->deltaX(),       // (-511 - 512) left X Axis
                   ctl->deltaY()        // (-511 - 512) left Y axis
    );
}

void dumpKeyboard(ControllerPtr ctl) {
    static const char* key_names[] = {
        // clang-format off
        // To avoid having too much noise in this file, only a few keys are mapped to strings.
        // Starts with "A", which is offset 4.
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
        "W", "X", "Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
        // Special keys
        "Enter", "Escape", "Backspace", "Tab", "Spacebar", "Underscore", "Equal", "OpenBracket", "CloseBracket",
        "Backslash", "Tilde", "SemiColon", "Quote", "GraveAccent", "Comma", "Dot", "Slash", "CapsLock",
        // Function keys
        "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12",
        // Cursors and others
        "PrintScreen", "ScrollLock", "Pause", "Insert", "Home", "PageUp", "Delete", "End", "PageDown",
        "RightArrow", "LeftArrow", "DownArrow", "UpArrow",
        // clang-format on
    };
    static const char* modifier_names[] = {
        // clang-format off
        // From 0xe0 to 0xe7
        "Left Control", "Left Shift", "Left Alt", "Left Meta",
        "Right Control", "Right Shift", "Right Alt", "Right Meta",
        // clang-format on
    };
    Serial.printf("idx=%d, Pressed keys: ", ctl->index());
    for (int key = Keyboard_A; key <= Keyboard_UpArrow; key++) {
        if (ctl->isKeyPressed(static_cast<KeyboardKey>(key))) {
            const char* keyName = key_names[key-4];
            Serial.printf("%s,", keyName);
       }
    }
    for (int key = Keyboard_LeftControl; key <= Keyboard_RightMeta; key++) {
        if (ctl->isKeyPressed(static_cast<KeyboardKey>(key))) {
            const char* keyName = modifier_names[key-0xe0];
            Serial.printf("%s,", keyName);
        }
    }
    Console.printf("\n");
}

void dumpBalanceBoard(ControllerPtr ctl) {
    Serial.printf("idx=%d,  TL=%u, TR=%u, BL=%u, BR=%u, temperature=%d\n",
                   ctl->index(),        // Controller Index
                   ctl->topLeft(),      // top-left scale
                   ctl->topRight(),     // top-right scale
                   ctl->bottomLeft(),   // bottom-left scale
                   ctl->bottomRight(),  // bottom-right scale
                   ctl->temperature()   // temperature: used to adjust the scale value's precision
    );
}

void processGamepad(ControllerPtr ctl) {
    // There are different ways to query whether a button is pressed.
    // By query each button individually:
    //  a(), b(), x(), y(), l1(), etc...
    if (ctl->a()) {
        // xbox a
        // ps4 X
    }

    if (ctl->b()) {
        // xbox b
        // ps4 O
    }

    if (ctl->x()) {
        // xbox X
        // ps4 square

    }

    l_x = ctl->axisX();
    l_y = ctl->axisY();
    r_x = ctl->axisRX();
    r_y = ctl->axisRY();

    notify();

    // Another way to query controller data is by getting the buttons() function.
    // See how the different "dump*" functions dump the Controller info.
    dumpGamepad(ctl);
}

void processMouse(ControllerPtr ctl) {
    // This is just an example.
    if (ctl->scrollWheel() > 0) {
        // Do Something
    } else if (ctl->scrollWheel() < 0) {
        // Do something else
    }

    // See "dumpMouse" for possible things to query.
    dumpMouse(ctl);
}

void processKeyboard(ControllerPtr ctl) {
    if (!ctl->isAnyKeyPressed())
        return;

    // This is just an example.
    if (ctl->isKeyPressed(Keyboard_A)) {
        // Do Something
        Serial.println("Key 'A' pressed");
    }

    // Don't do "else" here.
    // Multiple keys can be pressed at the same time.
    if (ctl->isKeyPressed(Keyboard_LeftShift)) {
        // Do something else
        Serial.println("Key 'LEFT SHIFT' pressed");
    }

    // Don't do "else" here.
    // Multiple keys can be pressed at the same time.
    if (ctl->isKeyPressed(Keyboard_LeftArrow)) {
        // Do something else
        Serial.println("Key 'Left Arrow' pressed");
    }

    // See "dumpKeyboard" for possible things to query.
    dumpKeyboard(ctl);
}

void processBalanceBoard(ControllerPtr ctl) {
    // This is just an example.
    if (ctl->topLeft() > 10000) {
        // Do Something
    }

    // See "dumpBalanceBoard" for possible things to query.
    dumpBalanceBoard(ctl);
}

void setUpPinModes() {
  pinMode(enableFrontRightMotor,OUTPUT);
  pinMode(FrontRightMotorPin1,OUTPUT);
  pinMode(FrontRightMotorPin2,OUTPUT);
  
  pinMode(enableFrontLeftMotor,OUTPUT);
  pinMode(FrontLeftMotorPin1,OUTPUT);
  pinMode(FrontLeftMotorPin2,OUTPUT);

  pinMode(enableBackRightMotor,OUTPUT);
  pinMode(BackRightMotorPin1,OUTPUT);
  pinMode(BackRightMotorPin2,OUTPUT);
  
  pinMode(enableBackLeftMotor,OUTPUT);
  pinMode(BackLeftMotorPin1,OUTPUT);
  pinMode(BackLeftMotorPin2,OUTPUT);

  //Set up PWM for motor speed
  ledcSetup(PWMSpeedChannel_1, PWMFreq, PWMResolution);
  ledcSetup(PWMSpeedChannel_2, PWMFreq, PWMResolution);
  ledcSetup(PWMSpeedChannel_3, PWMFreq, PWMResolution);
  ledcSetup(PWMSpeedChannel_4, PWMFreq, PWMResolution);
  ledcAttachPin(enableBackRightMotor, PWMSpeedChannel_1);
  ledcAttachPin(enableBackLeftMotor, PWMSpeedChannel_2);
  ledcAttachPin(enableFrontRightMotor, PWMSpeedChannel_3);
  ledcAttachPin(enableFrontLeftMotor, PWMSpeedChannel_4); 
    
  rotateMotor(BACK_RIGHT_MOTOR, 0);
  rotateMotor(BACK_LEFT_MOTOR, 0);
  rotateMotor(FRONT_RIGHT_MOTOR, 0);
  rotateMotor(FRONT_LEFT_MOTOR, 0);
}

void processControllers() {
    for (auto myController : myControllers) {
        if (myController && myController->isConnected() && myController->hasData()) {
            if (myController->isGamepad()) {
                processGamepad(myController);
            } else if (myController->isMouse()) {
                processMouse(myController);
            } else if (myController->isKeyboard()) {
                processKeyboard(myController);
            } else if (myController->isBalanceBoard()) {
                processBalanceBoard(myController);
            } else {
                Serial.println("Unsupported controller");
            }
        }
    }
}

void rotateMotor(int motorNumber, int motorSpeed) {
    // 修复：反转后轮的方向（或者前轮，根据实际情况选择）
    int actualSpeed = motorSpeed;
    

    // 只反转左后轮（BACK_LEFT_MOTOR）
    if (motorNumber == BACK_LEFT_MOTOR) {
        actualSpeed = -motorSpeed;
    }    
    


    if (actualSpeed < 0 && motorNumber == 1) // BACK_RIGHT_MOTOR
    {
        digitalWrite(BackRightMotorPin1, LOW);
        digitalWrite(BackRightMotorPin2, HIGH);  
    }
    else if (actualSpeed < 0 && motorNumber == 2) // BACK_LEFT_MOTOR  
    { 
        digitalWrite(BackLeftMotorPin1, LOW);
        digitalWrite(BackLeftMotorPin2, HIGH);
    }
    else if (actualSpeed < 0 && motorNumber == 3) // FRONT_RIGHT_MOTOR
    {
        digitalWrite(FrontRightMotorPin1, LOW);
        digitalWrite(FrontRightMotorPin2, HIGH);  
    }
    else if (actualSpeed < 0 && motorNumber == 4) // FRONT_LEFT_MOTOR  
    { 
        digitalWrite(FrontLeftMotorPin1, LOW);
        digitalWrite(FrontLeftMotorPin2, HIGH);
    } 

    else if (actualSpeed > 0 && motorNumber == 1) // BACK_RIGHT_MOTOR
    {
        digitalWrite(BackRightMotorPin1, HIGH);
        digitalWrite(BackRightMotorPin2, LOW);
    }
    else if (actualSpeed > 0 && motorNumber == 2) // BACK_LEFT_MOTOR
    {
        digitalWrite(BackLeftMotorPin1, HIGH);
        digitalWrite(BackLeftMotorPin2, LOW);
    }
    else if (actualSpeed > 0 && motorNumber == 3) // FRONT_RIGHT_MOTOR
    {
        digitalWrite(FrontRightMotorPin1, HIGH);
        digitalWrite(FrontRightMotorPin2, LOW);  
    }
    else if (actualSpeed > 0 && motorNumber == 4) // FRONT_LEFT_MOTOR  
    { 
        digitalWrite(FrontLeftMotorPin1, HIGH);
        digitalWrite(FrontLeftMotorPin2, LOW);
    }

    // 一套正确的停止逻辑
    else if (actualSpeed == 0 && motorNumber == 1) // BACK_RIGHT_MOTOR
    {
        digitalWrite(BackRightMotorPin1, LOW);
        digitalWrite(BackRightMotorPin2, LOW);     
    }
    else if (actualSpeed == 0 && motorNumber == 2) // BACK_LEFT_MOTOR
    {
        digitalWrite(BackLeftMotorPin1, LOW);
        digitalWrite(BackLeftMotorPin2, LOW);
    }
    else if (actualSpeed == 0 && motorNumber == 3) // FRONT_RIGHT_MOTOR
    {
        digitalWrite(FrontRightMotorPin1, LOW);
        digitalWrite(FrontRightMotorPin2, LOW);  
    }
    else if (actualSpeed == 0 && motorNumber == 4) // FRONT_LEFT_MOTOR
    {   
        digitalWrite(FrontLeftMotorPin1, LOW);
        digitalWrite(FrontLeftMotorPin2, LOW);   
    }
    ledcWrite(PWMSpeedChannel_1, abs(actualSpeed));
    ledcWrite(PWMSpeedChannel_2, abs(actualSpeed));
    ledcWrite(PWMSpeedChannel_3, abs(actualSpeed));
    ledcWrite(PWMSpeedChannel_4, abs(actualSpeed));
}

void moveCar(int inputValue) {
  switch(inputValue) {
    case FORWARD:
      rotateMotor(FRONT_RIGHT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(BACK_RIGHT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(FRONT_LEFT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(BACK_LEFT_MOTOR, MAX_MOTOR_SPEED);  
      break;
      
    case BACKWARD:
      rotateMotor(FRONT_RIGHT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(BACK_RIGHT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(FRONT_LEFT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(BACK_LEFT_MOTOR, -MAX_MOTOR_SPEED); 
      break;
  
    case LEFT:
      rotateMotor(FRONT_RIGHT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(BACK_RIGHT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(FRONT_LEFT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(BACK_LEFT_MOTOR, MAX_MOTOR_SPEED);   
      break;
  
    case RIGHT:
      rotateMotor(FRONT_RIGHT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(BACK_RIGHT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(FRONT_LEFT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(BACK_LEFT_MOTOR, -MAX_MOTOR_SPEED);  
      break;
  
    case FORWARD_LEFT:
      rotateMotor(FRONT_RIGHT_MOTOR, MAX_MOTOR_SPEED);
      // rotateMotor(BACK_RIGHT_MOTOR, STOP);
      // rotateMotor(FRONT_LEFT_MOTOR, STOP);
      rotateMotor(BACK_LEFT_MOTOR, MAX_MOTOR_SPEED);  
      break;
  
    case FORWARD_RIGHT:
      // rotateMotor(FRONT_RIGHT_MOTOR, STOP);
      rotateMotor(BACK_RIGHT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(FRONT_LEFT_MOTOR, MAX_MOTOR_SPEED);
      // rotateMotor(BACK_LEFT_MOTOR, STOP);  
      break;
  
    case BACKWARD_LEFT:
      // rotateMotor(FRONT_RIGHT_MOTOR, STOP);
      rotateMotor(BACK_RIGHT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(FRONT_LEFT_MOTOR, -MAX_MOTOR_SPEED);
      // rotateMotor(BACK_LEFT_MOTOR, STOP);   
      break;
  
    case BACKWARD_RIGHT:
      rotateMotor(FRONT_RIGHT_MOTOR, -MAX_MOTOR_SPEED);
      // rotateMotor(BACK_RIGHT_MOTOR, STOP);
      // rotateMotor(FRONT_LEFT_MOTOR, STOP);
      rotateMotor(BACK_LEFT_MOTOR, -MAX_MOTOR_SPEED);   
      break;
  
    case ROTATE_LEFT:
      rotateMotor(FRONT_RIGHT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(BACK_RIGHT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(FRONT_LEFT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(BACK_LEFT_MOTOR, -MAX_MOTOR_SPEED);  
      break;
  
    case ROTATE_RIGHT:
      rotateMotor(FRONT_RIGHT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(BACK_RIGHT_MOTOR, -MAX_MOTOR_SPEED);
      rotateMotor(FRONT_LEFT_MOTOR, MAX_MOTOR_SPEED);
      rotateMotor(BACK_LEFT_MOTOR, MAX_MOTOR_SPEED);   
      break;
  
    case STOP:
      rotateMotor(FRONT_RIGHT_MOTOR, STOP);
      rotateMotor(BACK_RIGHT_MOTOR, STOP);
      rotateMotor(FRONT_LEFT_MOTOR, STOP);
      rotateMotor(BACK_LEFT_MOTOR, STOP);    
      break;
  
    default:
      rotateMotor(FRONT_RIGHT_MOTOR, STOP);
      rotateMotor(BACK_RIGHT_MOTOR, STOP);
      rotateMotor(FRONT_LEFT_MOTOR, STOP);
      rotateMotor(BACK_LEFT_MOTOR, STOP);    
      break;
  }
}

void notify() {
  int LStickY = map( l_y, -511, 512, -254, 254);
  int LStickX = map( l_x, -511, 512, -254, 254);
  int RStickX = map( r_x, -511, 512, -254, 254);
  
  if (LStickY > 30 && LStickX < -30) {moveCar(FORWARD_LEFT);}
  else if (LStickY > 30 && LStickX > 30) {moveCar(FORWARD_RIGHT);}
  else if (LStickY < -30 && LStickX < -30) {moveCar(BACKWARD_LEFT);}
  else if (LStickY < -30 && LStickX > 30) {moveCar(BACKWARD_RIGHT);}
  else if (LStickY > 90) {moveCar(FORWARD);}
  else if (LStickY < -90) {moveCar(BACKWARD);}
  else if (LStickX < -90) {moveCar(LEFT);}
  else if (LStickX > 90) {moveCar(RIGHT);}
  else if (RStickX < -50) {moveCar(ROTATE_LEFT);}
  else if (RStickX > 50) {moveCar(ROTATE_RIGHT);}
  else {moveCar(STOP);}

// Print data for debugging purpose only
if (millis() - lastTimeStamp > 100)
  {
  Serial.print(LStickX);
  Serial.print(',');
  Serial.print(LStickY);
  Serial.print(',');
  Serial.print(RStickX);
  Serial.println();
  lastTimeStamp = millis();
  }

}

// Arduino setup function. Runs in CPU 1
void setup() {
    Serial.begin(115200);
    Serial.printf("Firmware: %s\n", BP32.firmwareVersion());
    const uint8_t* addr = BP32.localBdAddress();
    Serial.printf("BD Addr: %2X:%2X:%2X:%2X:%2X:%2X\n", addr[0], addr[1], addr[2], addr[3], addr[4], addr[5]);

    bd_addr_t controller_addr;
    sscanf_bd_addr(controller_addr_string, controller_addr);
    uni_bt_allowlist_add_addr(controller_addr);
    uni_bt_allowlist_set_enabled(true);

    // Setup the Bluepad32 callbacks
    BP32.setup(&onConnectedController, &onDisconnectedController);

    // "forgetBluetoothKeys()" should be called when the user performs
    // a "device factory reset", or similar.
    // Calling "forgetBluetoothKeys" in setup() just as an example.
    // Forgetting Bluetooth keys prevents "paired" gamepads to reconnect.
    // But it might also fix some connection / re-connection issues.
    BP32.forgetBluetoothKeys();

    // Enables mouse / touchpad support for gamepads that support them.
    // When enabled, controllers like DualSense and DualShock4 generate two connected devices:
    // - First one: the gamepad
    // - Second one, which is a "virtual device", is a mouse.
    // By default, it is disabled.
    BP32.enableVirtualDevice(false);

    setUpPinModes();

    Serial.println("=== MOTOR DIRECTION TEST ===");
    delay(2000);

    // 测试前进 - 所有轮子应该向前转
    Serial.println("TEST 1: FORWARD - all wheels should spin FORWARD");
    moveCar(FORWARD);
    delay(3000);
    moveCar(STOP);
    delay(1000);

    // 测试后退 - 所有轮子应该向后转  
    Serial.println("TEST 2: BACKWARD - all wheels should spin BACKWARD");
    moveCar(BACKWARD);
    delay(3000);
    moveCar(STOP);
    delay(1000);

    // 测试左转 - 左右轮应该反向
    Serial.println("TEST 3: LEFT - left and right wheels should spin opposite");
    moveCar(LEFT);
    delay(3000);
    moveCar(STOP);
    delay(1000);

    // 测试右转 - 左右轮应该反向
    Serial.println("TEST 4: RIGHT - left and right wheels should spin opposite");
    moveCar(RIGHT);
    delay(3000);
    moveCar(STOP);
    delay(1000);

    Serial.println("Direction test completed - observe wheel directions");

}

// Arduino loop function. Runs in CPU 1.
void loop() {
    // This call fetches all the controllers' data.
    // Call this function in your main loop.
    bool dataUpdated = BP32.update();
    if (dataUpdated)
        processControllers();

    // The main loop must have some kind of "yield to lower priority task" event.
    // Otherwise, the watchdog will get triggered.
    // If your main loop doesn't have one, just add a simple `vTaskDelay(1)`.
    // Detailed info here:
    // https://stackoverflow.com/questions/66278271/task-watchdog-got-triggered-the-tasks-did-not-reset-the-watchdog-in-time

    //     vTaskDelay(1);
    delay(150);
}
